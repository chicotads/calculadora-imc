# 🏋️ Calculadora de IMC

Calculadora de Índice de Massa Corporal (IMC) desenvolvida em Python, com classificação baseada na tabela oficial da Organização Mundial da Saúde (OMS).

---

## 📋 Sobre o Projeto

Este projeto foi desenvolvido como parte do meu aprendizado em Python, aplicando conceitos de:
- Funções e modularização
- Validação de entrada de dados
- Estruturas condicionais
- Formatação de saída no terminal

---

## ⚙️ Funcionalidades

- ✅ Calcula o IMC com base no peso e altura informados
- ✅ Classifica o resultado segundo a tabela da OMS
- ✅ Valida os dados inseridos pelo usuário
- ✅ Exibe tabela de referência completa
- ✅ Permite calcular múltiplas vezes sem reiniciar o programa

---

## 🚀 Como Usar

**Pré-requisito:** Python 3.x instalado

**1. Clone o repositório:**
```bash
git clone https://github.com/chicotads/calculadora-imc.git
```

**2. Acesse a pasta:**
```bash
cd calculadora-imc
```

**3. Execute o programa:**
```bash
python calculadora_imc.py
```

---

## 💻 Exemplo de Uso

```
========================================
       CALCULADORA DE IMC
========================================

Digite seu nome: Francisco
Digite seu peso (kg): 75
Digite sua altura (m): 1.75

========================================
  Resultado para: Francisco
========================================
  Peso:           75.0 kg
  Altura:         1.75 m
  IMC:            24.49
  Classificação:  Peso normal
========================================
```

---

## 📊 Tabela de Classificação (OMS)

| IMC | Classificação |
|---|---|
| Abaixo de 18.5 | Abaixo do peso |
| 18.5 – 24.9 | Peso normal |
| 25.0 – 29.9 | Sobrepeso |
| 30.0 – 34.9 | Obesidade Grau I |
| 35.0 – 39.9 | Obesidade Grau II |
| Acima de 40.0 | Obesidade Grau III |

---

## 🛠️ Tecnologias Utilizadas

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)

---

## 👨‍💻 Autor

**Francisco Carlos Silva Santos**  
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/francisco-ti)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/chicotads)
