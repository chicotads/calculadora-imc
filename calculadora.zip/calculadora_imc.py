# ============================================
# Calculadora de IMC
# Autor: Francisco Carlos Silva Santos
# GitHub: github.com/chicotads
# ============================================

def calcular_imc(peso, altura):
    """Calcula o IMC com base no peso e altura."""
    imc = peso / (altura ** 2)
    return round(imc, 2)

def classificar_imc(imc):
    """Classifica o IMC de acordo com a tabela da OMS."""
    if imc < 18.5:
        return "Abaixo do peso"
    elif 18.5 <= imc < 24.9:
        return "Peso normal"
    elif 25.0 <= imc < 29.9:
        return "Sobrepeso"
    elif 30.0 <= imc < 34.9:
        return "Obesidade Grau I"
    elif 35.0 <= imc < 39.9:
        return "Obesidade Grau II"
    else:
        return "Obesidade Grau III"

def exibir_tabela():
    """Exibe a tabela de classificação do IMC."""
    print("\n📊 Tabela de Classificação do IMC (OMS):")
    print("-" * 40)
    print(f"{'IMC':<20} {'Classificação'}")
    print("-" * 40)
    print(f"{'Abaixo de 18.5':<20} Abaixo do peso")
    print(f"{'18.5 – 24.9':<20} Peso normal")
    print(f"{'25.0 – 29.9':<20} Sobrepeso")
    print(f"{'30.0 – 34.9':<20} Obesidade Grau I")
    print(f"{'35.0 – 39.9':<20} Obesidade Grau II")
    print(f"{'Acima de 40.0':<20} Obesidade Grau III")
    print("-" * 40)

def main():
    print("=" * 40)
    print("       CALCULADORA DE IMC")
    print("=" * 40)

    while True:
        try:
            # Entrada de dados
            nome = input("\nDigite seu nome: ").strip()
            peso = float(input("Digite seu peso (kg): ").replace(",", "."))
            altura = float(input("Digite sua altura (m): ").replace(",", "."))

            # Validações
            if peso <= 0 or altura <= 0:
                print("⚠️  Peso e altura devem ser maiores que zero.")
                continue

            if altura > 3.0:
                print("⚠️  Altura inválida. Digite em metros (ex: 1.75)")
                continue

            # Cálculo e classificação
            imc = calcular_imc(peso, altura)
            classificacao = classificar_imc(imc)

            # Resultado
            print("\n" + "=" * 40)
            print(f"  Resultado para: {nome}")
            print("=" * 40)
            print(f"  Peso:           {peso} kg")
            print(f"  Altura:         {altura} m")
            print(f"  IMC:            {imc}")
            print(f"  Classificação:  {classificacao}")
            print("=" * 40)

            # Exibe tabela de referência
            exibir_tabela()

        except ValueError:
            print("⚠️  Entrada inválida. Digite apenas números.")
            continue

        # Continuar ou sair
        opcao = input("\nDeseja calcular novamente? (s/n): ").strip().lower()
        if opcao != "s":
            print("\nObrigado por usar a Calculadora de IMC!")
            print("github.com/chicotads")
            break

if __name__ == "__main__":
    main()
